# Student Management System

A simple Python CLI-based project to manage student records.

## Features
- Add Student
- View Students
- Search Student by Roll Number

## How to Run
python main.py

## Author
Piyush Khodre
